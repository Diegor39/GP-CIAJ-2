<?php
/*
session_start();
if(!isset($_SESSION['rol']))
	{
	header('location: loginbdh.php');
	}
else{
	if($_SESSION['rol']!="Capitan")
	{
		header('location: loginbdh.php');
	}	
}


$userP=$_SESSION['user'];
*/
include 'conectdb.php';


$FASE = htmlspecialchars($_POST['FASE']);
$TAREA = htmlspecialchars($_POST['TAREA']);
$RESPONSABLE = htmlspecialchars($_POST["RESPONSABLE"]);
$HORAS = htmlspecialchars($_POST["HORAS"]);
$F_INICIO = htmlspecialchars($_POST["F_INICIO"]);
$F_FIN = htmlspecialchars($_POST["F_FIN"]);
$descripcio = htmlspecialchars($_POST["descripcio"]);
$estatus = "To do";

$nueva_consulta1 = "SELECT ID_PROYECTO FROM CIAJ_P_FASE WHERE ID_FASE = ".$FASE."";
$resultado1 = $conexion->query($nueva_consulta1);
echo $resultado1;
echo $nueva_consulta1;
//$nueva_consulta = "INSERT INTO CIAJ_P_TAREA (ID_PROYECTO, ID_FASE, NOMBRE_TAREA, ID_USUARIO_T, HORAS_TAREA, F_INICIO_T,F_FIN_T,DESCRIPCION_T,ESTATUS_T) VALUES (".$resultado1.",".$FASE.", //'".$TAREA."', '".$RESPONSABLE."', ".$HORAS.",'".$F_INICIO."','".$F_FIN."','".$descripcio."','".$estatus."')";
	
	//$resultado = $conexion->query($nueva_consulta);
	//if ($resultado){
		//echo '<script> alert("Se ha creado la tarea"); </script>';
		//echo '<script> window.history.go(-1); </script>';
				
	//}
	//else {
		//echo "error";
	//}

?>
