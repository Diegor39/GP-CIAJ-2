 <?php
include 'conectdb.php';
			
$CONSP = "SELECT p.NOMBRE, p.ID_PROYECTO, f.ID_PROYECTO, f.ID_FASE,t.ID_FASE, SUM(t.HORAS_TAREA) FROM CIAJ_P_PROYECTO p, CIAJ_P_FASE f,CIAJ_P_TAREA t WHERE p.ID_PROYECTO=f.ID_PROYECTO";
			$CONSPR = mysqli_query($conexion,$CONSP);
			
				while ($row = mysqli_fetch_array($CONSPR)){
					echo "['".$row['NOMBRE']."',".$row['SUM(t.HORAS_TAREA)']."],";
			
		
		
		
		}
?>

