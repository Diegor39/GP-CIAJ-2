<?php
/*
session_start();
if(!isset($_SESSION['rol']))
	{
	header('location: loginbdh.php');
	}
else{
	if($_SESSION['rol']!="Capitan")
	{
		header('location: loginbdh.php');
	}	
}


$userP=$_SESSION['user'];
*/
include 'conectdb.php';


$nombre = htmlspecialchars($_POST['nombre']);
$encargado = htmlspecialchars($_POST['encargado']);
$tipo = htmlspecialchars($_POST["tipo"]);
$descripcion = htmlspecialchars($_POST["descripcion"]);
$estatus = "Activo";


		
$nueva_consulta = "INSERT INTO CIAJ_P_PROYECTO (NOMBRE, DESCRIPCION, ENCARGADO, TIPO, ESTATUS) VALUES ('".$nombre."', '".$descripcion."', '".$encargado."', '".$tipo."','".$estatus."')";
	
	$resultado = $conexion->query($nueva_consulta);
	if ($resultado){
		echo '<script> alert("Se ha creado el proyecto"); </script>';
		echo '<script> window.history.go(-1); </script>';
				
	}
	else {
		echo "error";
	}

?>
