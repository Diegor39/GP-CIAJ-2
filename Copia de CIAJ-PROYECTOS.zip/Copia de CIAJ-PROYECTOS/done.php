<?php

include 'conectdb.php';


$TAREA = htmlspecialchars($_GET['ta']);

		
$nueva_consulta = "UPDATE CIAJ_P_TAREA SET ESTATUS_T = 'Done', ACTIVO = '1' WHERE ID_TAREA = ".$TAREA."";

	$resultado = $conexion->query($nueva_consulta);
	if ($resultado){
		echo '<script> alert("Has finalizado una tarea"); </script>';
		echo '<script> window.history.go(-1); </script>';
				
	}
	else {
		echo $nueva_consulta;
		echo "error";
	}

?>