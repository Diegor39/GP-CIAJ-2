<?php
include 'conectdb.php';
echo $buspro;
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Mis Proyectos</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	

<script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
		<?php
			
			$buspro = htmlspecialchars($_POST["buspro"]);
			$CONSP = "select ID_PROYECTO, ESTATUS_T, COUNT(ESTATUS_T) FROM CIAJ_P_TAREA WHERE ID_PROYECTO = ".$buspro." GROUP BY ESTATUS_T";
			$CONSPR = mysqli_query($conexion,$CONSP);
			if($CONSPR){
				while ($row = mysqli_fetch_array($CONSPR)){
					echo "['".$row['ESTATUS_T']."',".$row['COUNT(ESTATUS_T)']."],";
				}	
			}else {
				$CONSP = "select ID_PROYECTO, ESTATUS_T, COUNT(ESTATUS_T) FROM CIAJ_P_TAREA GROUP BY ESTATUS_T";
				$CONSPR = mysqli_query($conexion,$CONSP);
				while ($row = mysqli_fetch_array($CONSPR)){
					echo "['".$row['ESTATUS_T']."',".$row['COUNT(ESTATUS_T)']."],";
				}
				
			}
				
			?>
          
        ]);

        var options = {
          title: 'Progreso de las tareas',
          pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>
	<script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([
          ['Proyecto', 'Horas'],
		
			<?php
			$CONSP = "SELECT ID_PROYECTO, SUM(HORAS_TAREA) FROM CIAJ_P_TAREA WHERE ID_PROYECTO= ".$buspro." GROUP BY ID_PROYECTO";
			$CONSPR = mysqli_query($conexion,$CONSP);
			if($CONSPR){
				while ($row = mysqli_fetch_array($CONSPR)){
					echo "['".$row['ID_PROYECTO']."',".$row['SUM(HORAS_TAREA)']."],";
				}
			}else{
				$CONSP = "SELECT ID_PROYECTO, SUM(HORAS_TAREA) FROM CIAJ_P_TAREA GROUP BY ID_PROYECTO";
				$CONSPR = mysqli_query($conexion,$CONSP);
				while ($row = mysqli_fetch_array($CONSPR)){
					echo "['".$row['ID_PROYECTO']."',".$row['SUM(HORAS_TAREA)']."],";
				}
			}
			?>
			
        
        ]);

        var options = {
          width: 800,
          legend: { position: 'none' },
          chart: {
            title: 'Horas por Proyecto',
            subtitle: '' },
          axes: {
            x: {
              0: { side: 'top', label: 'Proyectos'} // Top x-axis.
            }
          },
          bar: { groupWidth: "90%" }
        };

        var chart = new google.charts.Bar(document.getElementById('top_x_div'));
        // Convert the Classic options to Material options.
        chart.draw(data, google.charts.Bar.convertOptions(options));
      };
    </script>
</head>

<body>
	
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">CIAJ</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
	<li class="nav-item">
        <a class="nav-link" href="crear_proyectos.php">Crear proyectos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="mis_proyectos.php">Mis proyectos</a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="mi_calendario.php">Mi calendario</a>
      </li>
    </ul>
  </div>
</nav>
	<div class="container-fluid" style="position: absolute; right: 0;">
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" >Crear Proyecto</button>
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1">Crear Fase</button>
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModa" >Crear Tarea</button	
		</div>
	
	<div class="container-fluid" style="margin-top: 3%">
	
		
	<h1 class="display-4" style= "text-align: center; color: whitesmoke"><?php
			
			$CONSP = "SELECT P.NOMBRE, P.ID_PROYECTO, T.ID_PROYECTO FROM CIAJ_P_PROYECTO P, CIAJ_P_TAREA T WHERE P.ID_PROYECTO = ".$buspro." GROUP BY P.NOMBRE";
			$CONSPR = mysqli_query($conexion,$CONSP);
			if($CONSPR){
				while ($row = mysqli_fetch_array($CONSPR)){
					echo "ID0".$row['ID_PROYECTO']."  ".$row['NOMBRE']."";
				}
				
					
			}else {
					echo "Todos los proyectos";
				
			}
				
			?></h1>	
	<form action="mis_proyectos.php" method="post">
			<div class = "row">
				<div class="col-md-4 col-md-offset-4">
					<div class="input-group-prepend">
							<button class="btn btn-outline-secondary" type="submit">Buscar</button>
						
					<select id="PORTsa" class="form-control" name ="buspro" required>
        				<option selected>Proyecto</option>
						<?php
		  				$PORT = "SELECT NOMBRE, ID_PROYECTO FROM CIAJ_P_PROYECTO";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['ID_PROYECTO']."'> ID0".$row['ID_PROYECTO']."	".$row['NOMBRE']."</option>";
						}												
						?>
   				 		</select>
					</div>
				</div>
			</div>
		</form>
		
	</div>
	
	<div class="container-fluid">
  <div class="row">
    <div class="col">
      <div id="donutchart" style="width: 100%; height: 400px;"></div>
    </div>
    <div class="col">
      <table class="table" style="background-color: white">
  <thead>
    <tr>
      <th scope="col">Proyecto</th>
      <th scope="col">Fase</th>
      <th scope="col">Tarea</th>
		<th scope="col">Fecha Fin</th>
		<th scope="col">Estado</th>
    </tr>
 <?php
	$sql = "SELECT * FROM CIAJ_P_TAREA WHERE ACTIVO = 0";
	$result = mysqli_query($conexion,$sql);
	if ($result){
		while($row = mysqli_fetch_assoc($result)){
			
		echo "<tr>";
		echo "	<td>ID0".$row["ID_PROYECTO"]." ".$row["LAST_NAME"]."</td>";
		echo " 	<td> ID1".$row["ID_FASE"]."</td>";
		echo " 	<td>".$row["NOMBRE_TAREA"]."</td>";
		echo " 	<td>".$row["F_FIN_T"]."</td>";
		echo " 	<td>
		<a href='doing.php?ta=".$row["ID_TAREA"]."'>
		<button type='button' class= 'btn btn-warning'><svg width='1em' height='1em' viewBox='0 0 16 16' class='bi bi-clipboard' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
  		<path fill-rule='evenodd' d='M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z'/>
  		<path fill-rule='evenodd' d='M9.5 1h-3a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z'/></svg></button></a>
		<a href='done.php?ta=".$row["ID_TAREA"]."'>
		<button type='button' class= 'btn btn-success'><svg width='1em' height='1em' viewBox='0 0 16 16' class='bi bi-clipboard' fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
  		<path fill-rule='evenodd' d='M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z'/>
  		<path fill-rule='evenodd' d='M9.5 1h-3a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z'/></svg></button></a>
  		</td>";
		echo "</tr>";
		}
		
	}else{
		echo "error";
	}
?>
</table>
    </div>
  </div>
		</div>	

	<div class="container-fluid">
  <div class="row">
    <div class="col">
	
		<div class="col-12">
	<div class="card mb-2" style="width: 90%; background-color:rgba(0,0,0,0.5)">
  <div class="row no-gutters">
    <div class="col-md-4" >
		<div style="height: 70px">
		</div>
      <img src="https://image.flaticon.com/icons/svg/3324/3324778.svg" class="card-img" alt="...">
    </div>
    <div class="col-6" style="margin-top: 2%">
      <div class="card-body" >
        <h5 class="card-title" style="margin: 2%; text-align: center;"><font color="#FFFFFF" size="4">Datos personales</font></h5>
        <p class="card-text" >
			
		<p><font color="#FFFFFF" size="4">Nombre: <?php echo $NAME;?></font></p>  		
		<p><font color="#FFFFFF" size="4">Username:  <?php echo $USERNAME;?></font></p>		
		<p><font color="#FFFFFF" size="4">Total de horas: <?php echo $RESIDENCE;?></font></p>
		 
		 </p>
      </div>
    </div>
  </div>
		<div style="text-align: right; margin: 1%"><a href="https://nemonico.com.mx/diego/Covenant/ndaca.html"><font color="#777777">Actualizar mis datos</font></a></div>
</div>
	  </div>   
    </div>
    <div class="col">
       <div id="top_x_div" style="width: 100%; height: 100%;"></div>
    </div>
  </div>
	</div>
	


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Crear Proyecto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<form action="crear_proyecto_add.php" method="post">
				
				<div class="form-row">
					<div class="form-group col-md-6">
      					<label for="recipient-name" class="col-form-label"><font color="#414141" size="5">Nombre del proyecto</font></label>
      					<input type="text" class="form-control"  id="nombre" name="nombre" required>
    				</div>
					<div class="form-group col-md-6">
						<label for="recipient-name" class="col-form-label"><font color="#414141" size="5">Encargado</font></label>
						<select id="PORTsa" class="form-control" name ="encargado" >
						
        				<option selected></option>
						<?php
		  				$PORT = "SELECT USERNAME, ID_USUARIO FROM CIAJ_P_USUARIO";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['ID_USUARIO']."'>".$row['USERNAME']."</option>";
						}												
						?>
   				 </select>
     			 		
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
      					<label for="recipient-name" class="col-form-label"><font color="#414141" size="5">Tipo</font></label>
      					<input type="text" class="form-control"  id="tipo" name="tipo" required>
    				</div>
					<div class="form-group col-md-6">
						<label for="recipient-name" class="col-form-label"><font color="#414141" size="5">Institución</font></label>
     			 		<input type="text" class="form-control"  id="institucion" name="institucion" required>
					</div>
				</div>
				<div class="form-row">
	  				<div class="col-md-12 mb-3">
				 	<label for="recipient-name" class="col-form-label"><font color="#414141" size="5">Descipción del Proyecto</font></label>
    				<textarea class="form-control is-invalid" id="descripcion" rows="3" name="descripcion"required></textarea>
				</div>
  				</div>
				<button type="submit" class="btn btn-primary" style="height:100%; width:100%; position:relative; top:50%; "><font size="5" >Guardar proyecto</font></button>
				
		  </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Crear Fase</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<form action="crear_fase_add.php" method="post">
			<div class="form-row">
					<div class="form-group col-md-6">
      					<label for="Nacimiento"><font color="#414141" size="5">Proyecto</font></label>
      					 <select id="PORTsa" class="form-control" name ="proyecto" required>
        				<option selected>Proyecto</option>
						<?php
		  				$PORT = "SELECT NOMBRE, ID_PROYECTO FROM CIAJ_P_PROYECTO";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['ID_PROYECTO']."'>".$row['NOMBRE']."</option>";
						}												
						?>
   				 		</select>
						
    				</div>
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#414141" size="5">Fase</font></label>
     			 		<input type="text" class="form-control"  id="correo" name="fase" required>
					</div>
				</div>
					<div class="form-group col-md-5">
						<label for="Nacion"><font color="#414141" size="5">No. horas</font></label>
     			 		<input type="number" class="form-control"  id="correo" name="horas" required>
					</div>
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#414141" size="5">Inicio</font></label>
     			 		<input type="date" class="form-control"  id="correo" name="f_inicio" required>
					</div>
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#414141" size="5">Fin</font></label>
     			 		<input type="date" class="form-control"  id="correo" name="f_fin" required>
					</div>
					
	  				<div class="col-md-12 mb-3">
				 		<label for="Nacion"><font color="#414141" size="5">Descripción de la Fase</font></label>
    					<textarea class="form-control is-invalid" id="exampleFormControlTextarea1" rows="3" name="descripcion" required></textarea>				
  					</div>
						<button type="submit" class="btn btn-primary" style="height:100%; width:100%; position:relative; top:50%; "><font size="5">Agregar fase</font></button>
				</form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModa" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Crear Tarea</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<form action="crear_tarea.php" method="post">
				<div class="form-row">
	
							<div class="form-group col-md-6">
      							<label for="Nacimiento"><font color="#414141" size="5">Fase</font></label>
      					 		<select id="PORTsa" class="form-control" name ="FASE" required>
        				<option selected>Fase</option>
						<?php
		  				$PORT = "SELECT NOMBRE_FASE, ID_FASE FROM CIAJ_P_FASE";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['ID_FASE']."'>".$row['NOMBRE_FASE']."</option>";
						}												
						?>
   				 </select>
    						</div>
							<div class="form-group col-md-6">
								<label for="Nacion"><font color="#414141" size="5">Tarea</font></label>
     			 				<input type="text" class="form-control"  id="correo" name="TAREA" required>
							</div>
							<div class="form-group col-md-7">
								<label for="Nacion"><font color="#414141" size="5">Responsable</font></label>
     			 				<select id="PORTsa" class="form-control" name ="RESPONSABLE" required>
        				<option selected>Usuario</option>
						<?php
		  				$PORT = "SELECT USERNAME, ID_USUARIO FROM CIAJ_P_USUARIO";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['ID_USUARIO']."'>".$row['USERNAME']."</option>";
						}												
						?>
   				 </select>
								
							</div>
							<div class="form-group col-md-5">
								<label for="Nacion"><font color="#414141" size="5">No. horas</font></label>
     			 				<input type="number" class="form-control"  id="correo" name="HORAS" required>
							</div>
					</div>
							<div class="form-group col-md-6">
						<label for="Nacion"><font color="#414141" size="5">Inicio</font></label>
     			 		<input type="date" class="form-control"  id="correo" name="F_INICIO" required>
					</div>
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#414141" size="5">Fin</font></label>
     			 		<input type="date" class="form-control"  id="correo" name="F_FIN" required>
					</div>
							
	  						<div class="form-group col-md-12">
				 				<label for="Nacion"><font color="#414141" size="5">Descripción de la Tarea</font></label>
    							<textarea class="form-control is-invalid" id="exampleFormControlTextarea1" rows="3" name="descripcio" required></textarea>
				
  							</div>
						<button type="submit" class="btn btn-primary" style="height:100%; width:100%; position:relative; top:50%; "><font size="5">Agregar Tarea</font></button>
		</form>
      </div>
    </div>
  </div>
</div>



		
		
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>	
	
</body>
</html>