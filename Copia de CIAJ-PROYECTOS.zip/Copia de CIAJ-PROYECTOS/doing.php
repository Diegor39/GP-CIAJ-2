<?php

include 'conectdb.php';


$TAREA = htmlspecialchars($_GET['ta']);

		
$nueva_consulta = "UPDATE CIAJ_P_TAREA SET ESTATUS_T = 'Doing' WHERE ID_TAREA = ".$TAREA."";

	$resultado = $conexion->query($nueva_consulta);
	if ($resultado){
		echo '<script> alert("Has iniciado una tarea"); </script>';
		echo '<script> window.history.go(-1); </script>';
				
	}
	else {
		echo $nueva_consulta;
		echo "error";
	}

?>
