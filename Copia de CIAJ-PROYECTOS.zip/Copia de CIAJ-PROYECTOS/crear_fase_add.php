<?php
/*
session_start();
if(!isset($_SESSION['rol']))
	{
	header('location: loginbdh.php');
	}
else{
	if($_SESSION['rol']!="Capitan")
	{
		header('location: loginbdh.php');
	}	
}


$userP=$_SESSION['user'];
*/
include 'conectdb.php';


$proyecto = htmlspecialchars($_POST['proyecto']);
$fase = htmlspecialchars($_POST['fase']);
$horas = htmlspecialchars($_POST["horas"]);
$f_inicio = htmlspecialchars($_POST["f_inicio"]); 
$f_fin = htmlspecialchars($_POST["f_fin"]);
$descripcion = htmlspecialchars($_POST["descripcion"]);
$f_inicio = htmlspecialchars($_POST["f_inicio"]);
$estatus = "Activo";


		
$nueva_consulta = "INSERT INTO CIAJ_P_FASE (ID_PROYECTO, HORAS_FASE, F_INICIO, F_FIN, DESCRIPCION_F, ESTATUS_F, NOMBRE_FASE) VALUES ('".$proyecto."', '".$horas."', '".$f_inicio."', '".$f_fin."','".$descripcion."','".$estatus."','".$fase."')";
	
	$resultado = $conexion->query($nueva_consulta);
	if ($resultado){
		echo '<script> alert("Se ha creado el fase"); </script>';
		echo '<script> window.history.go(-1); </script>';
				
	}
	else {
		echo "error";
	}

?>