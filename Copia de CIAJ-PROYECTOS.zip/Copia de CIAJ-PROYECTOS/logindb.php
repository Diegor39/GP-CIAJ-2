<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Loading</title>
</head>

<body>
	<?php
	session_destroy();
	session_start();

	$varUsername = htmlspecialchars($_POST["n"]);
	$varPassword = htmlspecialchars($_POST["psw"]);

	//echo $varPassword;
	
	include 'conectdb.php';
	$sql="SELECT * FROM CIAJ_P_USUARIO WHERE USERNAME = '".$varUsername."'";
	$result=mysqli_query($conexion,$sql);
	$user=mysqli_fetch_assoc($result);
	
	if('admin' == $varPassword)
	{
		$_SESSION['user']=$user["USERNAME"];
		$_SESSION['rol']=$user["TIPO_USUARIO"];
	 
		$type=$user["TIPO_USUARIO"];
	    //echo $type;
		
		header('location: https://nemonico.com.mx/diego/CIAJ-PROYECTOS/mis_proyectos.php');
		
	}else{
		
		//echo $user;
		//echo $type;
		//echo $sql;
		//echo $result;
		//echo $varPassword;
		echo '<script> alert("datos incorrectos"); </script>';
		echo '<script> window.history.go(-1); </script>';
	}
	
	?>
	
</body>
</html>