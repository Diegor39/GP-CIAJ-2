<?php
$servername = "localhost";
$username = "sepherot_diego";
$password = "Ywx1pqRn5y";
$dbname = "sepherot_diegoBD";

$conexion = mysqli_connect($servername, $username, $password, $dbname);
/*
if (!$conexion){
	die("Connection failed: " . mysqli_connect_errno());
}else {
	echo 'conectado';
	return $conexion;
}*/
?>