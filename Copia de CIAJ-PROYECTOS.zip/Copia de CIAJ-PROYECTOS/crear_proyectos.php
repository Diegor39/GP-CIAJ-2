<?php
include 'conectdb.php';
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Guardar datos</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
	<body style="background-image: url('https://img4.goodfon.com/wallpaper/nbig/8/73/city-buildings-day-business.jpg');background-repeat: no-repeat;background-size: cover">
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">CIAJ</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
	<li class="nav-item">
        <a class="nav-link" href="crear_proyectos.php">Crear proyectos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="mis_proyectos.php">Mis proyectos</a>
      </li>
    </ul>
  </div>
</nav>
		
	<h1 class="display-4" style= "margin: 2%; text-align: center;">Crear proyecto</h1>
	
<div class="container">
  	<div class="row">
    	<div class="col">
      		<div class="container" style="background-color:rgba(0,0,0,0.5); align-content: center; top: 50%; padding: 50px 30px;
	borde-radius: 10px;">
				<form action="crear_proyecto_add.php" method="post">
				
				<div class="form-row">
					<div class="form-group col-md-6">
      					<label for="Nacimiento"><font color="#FFFFFF" size="5">Nombre del proyecto</font></label>
      					<input type="text" class="form-control"  id="nombre" name="nombre" required>
    				</div>
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#FFFFFF" size="5">Encargado</font></label>
						<select id="PORTsa" class="form-control" name ="encargado" >
						
        				<option selected></option>
						<?php
		  				$PORT = "SELECT PORT FROM C_PORT";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['PORT']."'>".$row['PORT']."</option>";
						}												
						?>
   				 </select>
     			 		
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
      					<label for="Nacimiento"><font color="#FFFFFF" size="5">Tipo</font></label>
      					<input type="text" class="form-control"  id="tipo" name="tipo" required>
    				</div>
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#FFFFFF" size="5">Institución</font></label>
     			 		<input type="text" class="form-control"  id="institucion" name="institucion" required>
					</div>
				</div>
				<div class="form-row">
	  				<div class="col-md-12 mb-3">
				 	<label for="Nacion"><font color="#FFFFFF" size="5">Descipción del Proyecto</font></label>
    				<textarea class="form-control is-invalid" id="descripcion" rows="3" name="descripcion"required></textarea>
				</div>
  				</div>
				<button type="submit" class="btn btn-primary" style="height:100%; width:100%; position:relative; top:50%; "><font size="5" >Guardar proyecto</font></button>
				
				</form>
			</div>
    	</div>
    	<div class="col">
      		<div class="container" style="background-color:rgba(0,0,0,0.5); align-content: center; top: 50%; padding: 50px 30px;
	borde-radius: 10px;">
				<form action="addclient.php" method="post">
				
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#FFFFFF" size="5">Proyecto</font></label>
     			 		<select id="PORTsa" class="form-control" name ="Psalida" required>
        				<option selected>Escoge un proyecto</option>
						<?php
		  				$PORT = "SELECT NOMBRE FROM CIAJ_P_PROYECTO";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['NOMBRE']."'>".$row['NOMBRE']."</option>";
						}												
						?>
   				 </select>
					</div>
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#FFFFFF" size="5">Usuario</font></label>
     			 		<select id="PORTsa" class="form-control" name ="Psalida" required>
        				<option selected>Escoge un Usuario</option>
						<?php
		  				$PORT = "SELECT PORT FROM C_PORT";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['PORT']."'>".$row['PORT']."</option>";
						}												
						?>
   				 </select>
					</div>
				</div>
				<button type="submit" class="btn btn-primary" style="height:100%; width:100%; position:relative; top:50%; "><font size="5" >Agregar participante</font></button>
				
				</form>
			</div>
    	</div>
  	</div>
</div>
	
		
		
		
<div class="container">
  <div class="row">
    <div class="col">
      <h1 class="display-4" style= "text-align: center; color: whitesmoke">Crear Fase</h1>
		<div class="container" style="background-color:rgba(0,0,0,0.5); align-content: center; top: 50%; padding: 50px 30px;
	borde-radius: 10px;">
			<form action="crear_fase_add.php" method="post">	
				<div class="form-row">
					<div class="form-group col-md-6">
      					<label for="Nacimiento"><font color="#FFFFFF" size="5">Proyecto</font></label>
      					 <select id="PORTsa" class="form-control" name ="proyecto" required>
        				<option selected>Proyecto</option>
						<?php
		  				$PORT = "SELECT NOMBRE, ID_PROYECTO FROM CIAJ_P_PROYECTO";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['ID_PROYECTO']."'>".$row['NOMBRE']."</option>";
						}												
						?>
   				 </select>
    				</div>
					<div class="form-group col-md-6">
						<label for="Nacion"><font color="#FFFFFF" size="5">Fase</font></label>
     			 		<input type="text" class="form-control"  id="correo" name="fase" required>
					</div>
					<div class="form-group col-md-5">
						<label for="Nacion"><font color="#FFFFFF" size="5">No. horas</font></label>
     			 		<input type="number" class="form-control"  id="correo" name="horas" required>
					</div>
					<div class="form-group col-md-3">
						<label for="Nacion"><font color="#FFFFFF" size="5">Fecha Inicio</font></label>
     			 		<input type="date" class="form-control"  id="correo" name="f_inicio" required>
					</div>
					<div class="form-group col-md-3">
						<label for="Nacion"><font color="#FFFFFF" size="5">Fecha Fin</font></label>
     			 		<input type="date" class="form-control"  id="correo" name="f_fin" required>
					</div>
					
	  				<div class="col-md-12 mb-3">
				 		<label for="Nacion"><font color="#FFFFFF" size="5">Descripción de la Fase</font></label>
    					<textarea class="form-control is-invalid" id="exampleFormControlTextarea1" rows="3" name="descripcion" required></textarea>				
  					</div>
						<button type="submit" class="btn btn-primary" style="height:100%; width:100%; position:relative; top:50%; "><font size="5">Agregar fase</font></button>
				</form>
			</div>
		</div>
	
    
    	<div class="col">
      		<h1 class="display-4" style= "text-align: center; color: whitesmoke">Crear Tarea</h1>
				<div class="container" style="background-color:rgba(0,0,0,0.5); align-content: center; top: 50%; padding: 50px 30px;
	borde-radius: 10px;">
			
					<form action="crear_tarea.php" method="post">
				
						<div class="form-row">
							<div class="form-group col-md-6">
      							<label for="Nacimiento"><font color="#FFFFFF" size="5">Fase</font></label>
      					 		<select id="PORTsa" class="form-control" name ="FASE" required>
        				<option selected>Fase</option>
						<?php
		  				$PORT = "SELECT NOMBRE_FASE, ID_FASE FROM CIAJ_P_FASE";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['ID_FASE']."'>".$row['NOMBRE_FASE']."</option>";
						}												
						?>
   				 </select>
    						</div>
							<div class="form-group col-md-6">
								<label for="Nacion"><font color="#FFFFFF" size="5">Tarea</font></label>
     			 				<input type="text" class="form-control"  id="correo" name="TAREA" required>
							</div>
							<div class="form-group col-md-7">
								<label for="Nacion"><font color="#FFFFFF" size="5">Responsable</font></label>
     			 				<select id="PORTsa" class="form-control" name ="RESPONSABLE" required>
        				<option selected>Usuario</option>
						<?php
		  				$PORT = "SELECT PORT FROM C_PORT";
						$PORTR = mysqli_query($conexion,$PORT);
						while ($row = mysqli_fetch_array($PORTR)){
							echo "<option value='".$row['PORT']."'>".$row['PORT']."</option>";
						}												
						?>
   				 </select>
							</div>
							<div class="form-group col-md-5">
								<label for="Nacion"><font color="#FFFFFF" size="5">No. horas</font></label>
     			 				<input type="number" class="form-control"  id="correo" name="HORAS" required>
							</div>
							<div class="form-group col-md-3">
						<label for="Nacion"><font color="#FFFFFF" size="5">Fecha Inicio</font></label>
     			 		<input type="date" class="form-control"  id="correo" name="F_INICIO" required>
					</div>
					<div class="form-group col-md-3">
						<label for="Nacion"><font color="#FFFFFF" size="5">Fecha Fin</font></label>
     			 		<input type="date" class="form-control"  id="correo" name="F_FIN" required>
					</div>
							
	  						<div class="form-group col-md-12">
				 				<label for="Nacion"><font color="#FFFFFF" size="5">Descripción de la Tarea</font></label>
    							<textarea class="form-control is-invalid" id="exampleFormControlTextarea1" rows="3" name="descripcio" required></textarea>
				
  							</div>
						<button type="submit" class="btn btn-primary" style="height:100%; width:100%; position:relative; top:50%; "><font size="5">Agregar Tarea</font></button>
					</form>
						</div>
				</div>
    	</div>
  </div>
</div>

		

		
		
	
			
	
	
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	</body>


</html>
